# Online Shopping Cart E-Commerce Website
This is an ecommerse website build for selling of any products online.
In this project we have mainly considered to adding the products to the users cart and again let them decide the amount of item to buy.
The users can increase or decrease the items amount in the cart. 
After that the user may pay and get the order successful.
The Project also uses the mail facilities to the users.
### The users will get a mail to their registered mail Id during:-
- New User Registration
- Order Successfully Placed
- The Item was not available but now it got available in the store
- Successful Delivery of Item

### The Technologies Used in this Project are:-
- HTML
- CSS
- Javascript
- Bootstrap
- Java
- JDBC
- JSP
- Servlets
- MySql

### IDE Used:-
- Eclipse Express Edition


